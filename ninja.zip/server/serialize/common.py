# from flask import jsonify
# from config import SUCCESS_CODE, FAIL_CODE

# # serialize the common response
# def common_response(code,data,msg):
#     response = {
#         'code': code,
#         'data': data,
#         'msg': msg
#     }
#     return jsonify(response)