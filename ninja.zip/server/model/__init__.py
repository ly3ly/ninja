from model.model_interface import *

DB = {
    'interfaceDB':{},
    'userDB':{}
}


# DB = {
#     'interfaceDB':{
#         "uuid1":{
#             "api_name":"api1"
#         },
#         "uuid2":{
#             "api_name":"api2"
#         }
#     },
# }