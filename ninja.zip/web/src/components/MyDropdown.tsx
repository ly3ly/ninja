import React, { useState } from 'react';
import { FormControl, InputLabel, Select, MenuItem, Typography } from '@mui/material';

interface MyDropdownProps {
    onDropdownChange: (option: string) => void
    title: string
    content: any[]
}
const MyDropdown: React.FC<MyDropdownProps> = ({ onDropdownChange, title, content }) => {

    const [selectedOption, setSelectedOption] = useState<string>('');

    const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
        setSelectedOption(event.target.value as string);
        onDropdownChange(selectedOption)
    };

    return (
        <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>{title}</InputLabel>
            <Select value={selectedOption} onChange={handleChange as any}>
                {content.map((item) => (
                    <MenuItem key={item} onClick={() => { }} value={item}>
                        <Typography textAlign="left">{item}</Typography>
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    );
};

export default MyDropdown;