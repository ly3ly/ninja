import * as React from 'react';
import ResponsiveAppBar from './AppBar';
import { Container } from '@mui/system';
import { useEffect } from 'react';
import { createAPI } from '../apis/createAPI';
import { styled } from '@mui/system';
import Grid from '@mui/material/Grid';
import Link from '@mui/material/Link';
import { Menu, Divider } from '@mui/material';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import CssBaseline from '@mui/material/CssBaseline';
import { TextField, Select, MenuItem, FormControl, FormLabel, RadioGroup, FormControlLabel, Radio, Checkbox, Button, Box } from '@mui/material';

import MyDropdown from './MyDropdown';
import MyTable from './MyTable';
import MyEditTable from './MyEditTable';

const methods = ['GET', 'POST', 'PUT', 'DELETE']
export default function CreateAPI() {
    const mockdata = {
        "api_name": "update user information",
        "api_url": "https://www.testprj.com/api/user",
        "api_method": "PUT",
        "api_respose": {
            "success_code_value": "0",
            "success_code_type": "number",
            "fail_code_value": "999",
            "fail_code_type": "number"
        },
        "api_body": [
            {
                "para_name": "userid",
                "para_type": "number",
                "para_required": true,
                "number_para_constrain": {
                    "min": -1,
                    "max": 100
                }
            },
            {
                "para_name": "username",
                "para_type": "string",
                "para_required": true
            },
            {
                "para_name": "user_language",
                "para_type": "string",
                "para_required": true,
                "string_para_constrain": [
                    "zh-cn",
                    "zh-hk",
                    "zh-tw"
                ]
            },
            {
                "para_name": "user_detail",
                "para_type": "object",
                "para_required": false,
                "object_para_constrain": [
                    {
                        "para_name": "user_gender",
                        "para_type": "string",
                        "para_required": true,
                        "string_para_constrain": [
                            "male",
                            "female",
                            "other"
                        ]
                    },
                    {
                        "para_name": "user_age",
                        "para_type": "number",
                        "para_required": true,
                        "number_para_constrain": {
                            "min": 18,
                            "max": 120
                        }
                    }
                ]
            }
        ]
    }
    const [showNodal, setShowNodal] = React.useState(false);




    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        console.log(mockdata);

        //传到后端
        const res = createAPI(mockdata);


    };

    const handleDropdownChange = (option: string) => {
        console.log(option);
    }

    return <div>
        <Container component="main">
            {/* <CssBaseline /> */}
            <Box
                component="form" onSubmit={handleSubmit}
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                }}
            >
                <Grid container sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                }}>
                    <Grid item xs={3}>
                        <MyDropdown title='METHOD' content={methods} onDropdownChange={handleDropdownChange} />
                    </Grid>
                    <Grid item xs={9}>
                        <TextField
                            required
                            fullWidth
                            id="api_url"
                            label="URL"
                            name="api_url"
                            autoComplete="request url"
                        />
                    </Grid>
                </Grid>
                <CustomDivider />

                <Typography>
                    Body Parameters
                </Typography>
                <MyEditTable />
                {/* <Box>
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        label="Email Address"
                        name="email"
                        autoComplete="email"
                        autoFocus
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                    />
                </Box> */}

                <Typography>
                    Response Parameters
                </Typography>

                {/* <Box>
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        label="Email Address"
                        name="email"
                        autoComplete="email"
                        autoFocus
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                    />



                </Box> */}
                <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    sx={{ mt: 3, mb: 2 }}
                >
                    Create
                </Button>
            </Box>
        </Container>
    </div >

    // return <div>
    //     <div>
    //         这里应该有个表单（录入信息，生成下面的json，谁有兴趣开发？）
    //     </div>
    //     <div>
    //         {JSON.stringify(mockdata)}
    //     </div>

    //         <Button
    //             type="submit"
    //             fullWidth
    //             variant="contained"
    //             sx={{ mt: 3, mb: 2 }}
    //         >
    //             创建
    //         </Button>
    //     </Box>

    // </div>;
}


const CustomDivider = styled(Divider)`
  margin: 16px 0;
`;