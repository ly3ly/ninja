import * as React from 'react';
import ResponsiveAppBar from './AppBar';
import { Container } from '@mui/system';
import { useEffect } from 'react';
import { styled } from '@mui/system';
import Grid from '@mui/material/Grid';
import Link from '@mui/material/Link';
import { Menu, Divider, Input } from '@mui/material';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import CssBaseline from '@mui/material/CssBaseline';
import { TextField, Select, MenuItem, FormControl, FormLabel, RadioGroup, FormControlLabel, Radio, Checkbox, Button, Box } from '@mui/material';

import MyDropdown from './MyDropdown';
import MyTable from './MyTable';

const CustomTextField = (data: any) => {
    const inputStyles = {
        border: 'none',
        borderBottom: 'none',
        // borderBottom: '1px solid gray',
        outline: 'none',
    };

    return (
        <Input defaultValue={data}></Input>
    );
};

export default function MyEditTable() {
    const title = ['Parameter Name', 'Parameter Type', 'Parameter Required', 'Parameter Constrain'];
    const contents = [
        {
            "param_name": "username",
            "param_type": "string",
            "param_required": true,
            "constrain": "5\,10"
        }
    ]
    return <Container>
        <Grid container spacing={3} justifyContent="space-between">
            {title.map(item => {
                return <Grid item xs={12 / title.length}>
                    <Typography>{item}</Typography>
                </Grid>
            })}
            {
                contents.map(content => {
                    return <Grid container spacing={3} justifyContent="space-between">
                        {/* {(content.param_name)} */}
                        <Grid item xs={12 / 4} >
                            <Input defaultValue={content.param_name}></Input>
                        </Grid>
                        <Grid item xs={12 / 4} >
                            <Input defaultValue={content.param_type}></Input>
                        </Grid >
                        <Grid item xs={12 / 4} justifySelf={'center'}>
                            <Checkbox checked={content.param_required}></Checkbox>
                        </Grid>
                        <Grid item xs={12 / 4}>
                            <Input defaultValue={content.constrain}></Input>
                        </Grid>
                    </Grid>
                })
            }

            {/* <Grid item xs={3}>
                <Typography>{title[0]}</Typography>
            </Grid>
            <Grid item xs={3}>
            </Grid>
            <Grid item xs={3}>
                <CustomTextField></CustomTextField>
            </Grid> */}

        </Grid>
    </Container>

}