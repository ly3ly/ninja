// import * as React from 'react';
// import Paper from '@mui/material/Paper';
// import Table from '@mui/material/Table';
// import TableBody from '@mui/material/TableBody';
// import TableCell from '@mui/material/TableCell';
// import TableContainer from '@mui/material/TableContainer';
// import TableHead from '@mui/material/TableHead';
// import TablePagination from '@mui/material/TablePagination';
// import TableRow from '@mui/material/TableRow';

// interface Column {
//     id: 'name' | 'type' | 'constrain'
//     label: string;
//     minWidth?: number;
//     align?: 'right';
//     format?: (value: number) => string;
// }

// const columns: readonly Column[] = [
//     { id: 'name', label: 'Parameter Name', minWidth: 170 },
//     { id: 'type', label: 'Parameter Type', minWidth: 100 },
//     { id: 'constrain', label: 'Parameter Constrain', minWidth: 170 },
//     // {
//     //     id: 'population',
//     //     label: 'Population',
//     //     minWidth: 170,
//     //     align: 'right',
//     //     format: (value: number) => value.toLocaleString('en-US'),
//     // },
//     // {
//     //     id: 'size',
//     //     label: 'Size\u00a0(km\u00b2)',
//     //     minWidth: 170,
//     //     align: 'right',
//     //     format: (value: number) => value.toLocaleString('en-US'),
//     // },
//     // {
//     //     id: 'density',
//     //     label: 'Density',
//     //     minWidth: 170,
//     //     align: 'right',
//     //     format: (value: number) => value.toFixed(2),
//     // },
// ];

// interface Data {
//     name: string;
//     type: string;
//     constrain: { min: any, max: any } | any[]
// }

// function createData(
//     name: string,
//     type: string,
//     constrain: { min: any, max: any } | any[]
// ): Data {
//     return { name, type, constrain };
// }

// const rows = [
//     createData('param1', 'number', { min: 5, max: 10 }),
//     createData('param2', 'string', { min: 5, max: 10 }),
//     createData('param3', 'array', [1, 2, 3]),
// ];

// export default function StickyHeadTable() {
//     const [page, setPage] = React.useState(0);
//     const [rowsPerPage, setRowsPerPage] = React.useState(10);

//     const handleChangePage = (event: unknown, newPage: number) => {
//         setPage(newPage);
//     };

//     const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
//         setRowsPerPage(+event.target.value);
//         setPage(0);
//     };

//     return (
//         <Paper sx={{ width: '100%', overflow: 'hidden' }}>
//             <TableContainer sx={{ maxHeight: 440 }}>
//                 <Table stickyHeader aria-label="sticky table">
//                     <TableHead>
//                         <TableRow>
//                             {columns.map((column) => (
//                                 <TableCell
//                                     key={column.id}
//                                     align={column.align}
//                                     style={{ minWidth: column.minWidth }}
//                                 >
//                                     {column.label}
//                                 </TableCell>
//                             ))}
//                         </TableRow>
//                     </TableHead>
//                     <TableBody>
//                         {rows
//                             // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
//                             .map((row) => {
//                                 return (
//                                     <TableRow hover role="checkbox" tabIndex={-1} key={row.name}>
//                                         {columns.map((column) => {
//                                             const value = row[column.id];
//                                             return (
//                                                 <TableCell key={column.id} align={column.align}>
//                                                     {column.format && typeof value === 'number'}
//                                                 </TableCell>
//                                             );
//                                         })}
//                                     </TableRow>
//                                 );
//                             })}
//                     </TableBody>
//                 </Table>
//             </TableContainer>
//             {/* <TablePagination
//                 rowsPerPageOptions={[10, 25, 100]}
//                 component="div"
//                 count={rows.length}
//                 rowsPerPage={rowsPerPage}
//                 page={page}
//                 onPageChange={handleChangePage}
//                 onRowsPerPageChange={handleChangeRowsPerPage}
//             /> */}
//         </Paper>
//     );
// }


import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, TextField, IconButton } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';

interface RowData {
    id: number,
    param_name: string,
    param_type: string,
    constrain: any
}

const EditableTable: React.FC = () => {
    const [rows, setRows] = useState<RowData[]>([
        { id: 0, param_name: "username", param_type: 'string', constrain: '5,10' },
    ]);
    const [editingRowId, setEditingRowId] = useState<number | null>(null);
    const [editedName, setEditedName] = useState('');
    const [editedType, seteditedType] = useState('');
    const [editedConstrain, seteditedConstrain] = useState('');
    const handleEditRow = (rowId: number) => {
        const editedRow = rows.find((row) => row.id === rowId);
        if (editedRow) {
            setEditingRowId(rowId);
            setEditedName(editedRow.param_name);
            seteditedType(editedRow.param_type);
            seteditedConstrain(editedRow.constrain);
        }
    };

    const handleSaveRow = (rowId: number) => {
        const updatedRows = rows.map((row) => {
            if (row.id === rowId) {
                return { ...row, name: editedName, age: editedType };
            }
            return row;
        });
        setRows(updatedRows);
        setEditingRowId(null);
    };

    const handleCancelEdit = () => {
        setEditingRowId(null);
    };

    const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setEditedName(event.target.value);
    };

    const handleTypeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        seteditedType((event.target.value));
    };

    const handleConstrainChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        seteditedConstrain((event.target.value));
    };

    return (
        <TableContainer component={Paper}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>Parameter Name</TableCell>
                        <TableCell>Parameter Type</TableCell>
                        <TableCell>Parameter Constrain</TableCell>
                        <TableCell>Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rows.map((row) => (
                        <TableRow key={row.id}>
                            <TableCell>
                                {editingRowId === row.id ? (
                                    <TextField value={editedName} onChange={handleNameChange} />
                                ) : (
                                    row.param_name
                                )}
                            </TableCell>
                            <TableCell>
                                {editingRowId === row.id ? (
                                    <TextField value={editedType} onChange={handleTypeChange} />
                                ) : (
                                    row.param_type
                                )}
                            </TableCell>
                            <TableCell>
                                {editingRowId === row.id ? (
                                    <TextField value={editedType} onChange={handleConstrainChange} />
                                ) : (
                                    row.constrain
                                )}
                            </TableCell>
                            <TableCell>
                                {editingRowId === row.id ? (
                                    <>
                                        <IconButton onClick={() => handleSaveRow(row.id)}>
                                            <SaveIcon />
                                        </IconButton>
                                        <IconButton onClick={handleCancelEdit}>
                                            <CancelIcon />
                                        </IconButton>
                                    </>
                                ) : (
                                    <IconButton onClick={() => handleEditRow(row.id)}>
                                        <EditIcon />
                                    </IconButton>
                                )}
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default EditableTable;